/* source: xio-system.h */
/* Copyright Gerhard Rieger and contributors (see file CHANGES) */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_system_h_included
#define __xio_system_h_included 1

extern const struct addrdesc xioaddr_system;

#endif /* !defined(__xio_system_h_included) */
